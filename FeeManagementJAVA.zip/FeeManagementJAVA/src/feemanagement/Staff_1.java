/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feemanagement;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author #RUSHI#
 */
@Entity
@Table(name = "staff", catalog = "fee", schema = "")
@NamedQueries({
    @NamedQuery(name = "Staff_1.findAll", query = "SELECT s FROM Staff_1 s")
    , @NamedQuery(name = "Staff_1.findBySId", query = "SELECT s FROM Staff_1 s WHERE s.sId = :sId")
    , @NamedQuery(name = "Staff_1.findBySUser", query = "SELECT s FROM Staff_1 s WHERE s.sUser = :sUser")
    , @NamedQuery(name = "Staff_1.findBySPass", query = "SELECT s FROM Staff_1 s WHERE s.sPass = :sPass")})
public class Staff_1 implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "s_id")
    private Integer sId;
    @Basic(optional = false)
    @Column(name = "s_user")
    private String sUser;
    @Basic(optional = false)
    @Column(name = "s_pass")
    private String sPass;

    public Staff_1() {
    }

    public Staff_1(Integer sId) {
        this.sId = sId;
    }

    public Staff_1(Integer sId, String sUser, String sPass) {
        this.sId = sId;
        this.sUser = sUser;
        this.sPass = sPass;
    }

    public Integer getSId() {
        return sId;
    }

    public void setSId(Integer sId) {
        this.sId = sId;
    }

    public String getSUser() {
        return sUser;
    }

    public void setSUser(String sUser) {
        this.sUser = sUser;
    }

    public String getSPass() {
        return sPass;
    }

    public void setSPass(String sPass) {
        this.sPass = sPass;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sId != null ? sId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Staff_1)) {
            return false;
        }
        Staff_1 other = (Staff_1) object;
        if ((this.sId == null && other.sId != null) || (this.sId != null && !this.sId.equals(other.sId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "feemanagement.Staff_1[ sId=" + sId + " ]";
    }
    
}
